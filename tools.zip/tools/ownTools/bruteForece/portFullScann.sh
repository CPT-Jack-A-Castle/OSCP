for port in $(seq 1 65535) ; do (echo Scann_Port > /dev/tcp/172.19.0.2/$port && echo "open =  $port") 2> /dev/null; done 
