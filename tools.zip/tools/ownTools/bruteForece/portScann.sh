for port in 21 22 25 51 80 443 445 8080 8443; do (echo Scann_Port > /dev/tcp/172.19.0.2/$port && echo "open =  $port") 2> /dev/null; done 
